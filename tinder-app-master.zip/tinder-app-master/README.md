# Tinder Android app
An Android app using the Tinder API, which offers some extra features:
  - Know who liked you in advance
  - Change your position
  - Have multiple profiles at the same time
  - Like all the recommendations with just a click
  - Know the last time your matches logged in
  - View all the users who blocked you

There's still some work left to have a proper login with facebook, so by now, follow this [guide](http://jaanus.com/debugging-http-on-an-android-phone-or-tablet-with-charles-proxy-for-fun-and-profit/) to get the Tinder token and then place it in the build type named DEFAULT_TOKEN.
